package DSAPA5;

public class CircularLinkedList{

    private int len = 0;
    protected Node head = null;
    protected Node tail = null;


    public void addToEnd(String value){
 
        Node newNode = new Node(value);
        
        if(isEmpty()){  
            head= tail = newNode;
            head.nextNode = head.prevNode = tail.nextNode = tail.prevNode = head;
            len++;
            return;
        }

        Node lastNode = tail;
        tail = newNode;
        tail.nextNode = head;
        head.prevNode = lastNode.nextNode = tail;
        tail.prevNode = lastNode;
        len++;
    }


    public void addToFront(String value){
  
        Node newNode = new Node(value);

        if(isEmpty()){  
            head= tail = newNode;
            head.nextNode = head.prevNode = tail.nextNode = tail.prevNode = head;
            len++;
            return;
        }

        Node firstNode = head;
        head = newNode;
        head.nextNode = firstNode;
        firstNode.prevNode = tail.nextNode = head;
        head.prevNode = tail;
        len++;
    }


    public void addAfter(String value,int searchVal){
 
        if(searchVal==0){
            addToFront(value);
        }
        else if(searchVal==len-1){
            addToEnd(value);
        }
        else if(searchVal>0 && searchVal<len-1){
            Node newNode = new Node(value);
            Node mid = newNode;
            Node temp = head;
            for(int i=0; i<searchVal; i++){ 
                temp= temp.nextNode;
            }
            Node next_to_searchVal = temp.nextNode;

            temp.nextNode = next_to_searchVal.prevNode = mid;
            mid.nextNode = next_to_searchVal;
            mid.prevNode = temp;
            len++;
        }
        else{
            System.out.println("Deletion not possible!"); 
        }
        
    }


    public void delAtEnd(){
 
        if(isEmpty()){
            System.out.println("The list empty!");
            return;
        }
        else if(len==1){
            head = tail = null;
        }
        else{
            Node temp = tail.prevNode;
            head.prevNode = temp;
            temp.nextNode = head;
            tail = temp;
        }
        len--;
    }


    public void delAtFront(){

        if(isEmpty()){
            System.out.println("The list empty!");
            return;
        }
        else if(len==1){
            head = tail = null;
        }
        else{
            Node temp = head.nextNode;
            tail.nextNode = temp;
            temp.prevNode = tail;
            head = temp;   
        }
        len--;
    }


    public void delNode(int pos){
 
        if(pos==0){
            delAtFront();
        }
        else if(pos==len-1){
            delAtEnd();
        }
        else if(pos>0 && pos<len-1){
            Node temp = head;
            for(int i=0; i<pos;i++){
                temp= temp.nextNode;
            }
            Node temp_next = temp.nextNode;
            Node temp_prev = temp.prevNode;
            temp_prev.nextNode = temp_next;
            temp_next.prevNode = temp_prev;
            len--;
        }
        else{
            System.out.println("Deletion not possible!"); 
        }   
    }


    public void display(){
 
        Node temp = head;
        for(int i=1;i<=len;i++){
            System.out.print(" <=> "+temp.value );
            temp = temp.nextNode;
        }
        
    }


    public boolean isEmpty(){
 
        return head == null;
    }


    public int getLen(){
 
        return len;
    }
}