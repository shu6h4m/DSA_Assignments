package DSAPA5;

import java.util.Scanner;

public class Queue {


    CircularLinkedList cll = new CircularLinkedList();

    public void enqueue(String value){
 
        cll.addToEnd(value);
    }

    public void dequeue(){
   
        if(isEmptyQueue()){
            System.out.println("Queue is empty.");
            return;
        }
        cll.delAtFront();
    }

    public String displayFront(){
  
        if(isEmptyQueue()){
            return "Queue is empty.";
        }
        return cll.head.value;
    }

    public void displayQueue(){
   
        if(isEmptyQueue()){
            System.out.println("Queue is empty.");
            return;
        }
        cll.display();
    }

    public boolean isEmptyQueue(){

        return cll.isEmpty();
    }


    public static void main(String[] args){

        Queue q = new Queue();
        Scanner sc = new Scanner(System.in);
        while(true){
            String value;
            System.out.println("\n------------------------Menu-------------------------");
            System.out.println("1. Enqueue.\n2. Dequeue.\n3. Display front of Queue.\n4. Display Queue. \n5. Is Empty ?.");
            System.out.println("-----------------------------------------------------");
            System.out.print("Enter Your Choice : ");
            int op = sc.nextInt();
                    if(op == 0){
                        //To exit from loop.
                        break;
                    }
                    switch(op){
                        case 1:
                            System.out.print("Enter Value : ");
                            value = sc.next();
                            q.enqueue(value);
                            break;
                        case 2:
                            q.dequeue();
                            break;
                        case 3:
                            System.out.print(q.displayFront());
                            break;
                        case 4:
                            q.displayQueue();
                            break;
                        case 5:
                            if(q.isEmptyQueue()){
                                System.out.println("Queue is Empty!");
                            }else{
                                System.out.println("Queue is Not Empty!");
                            }
                            break;
                        default:
                            System.out.println("Please Enter a valid Choice ! .");
                            break;  
                    }
        }
    }
}
