package DSAPA5;
class Node{

    String value;
    Node nextNode;
    Node prevNode;

    //constructor
    public Node(String value){
        this.value = value;
    }
}