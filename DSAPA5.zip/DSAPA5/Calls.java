package DSAPA5;

import java.util.Scanner;
import java.util.Random;

public class Calls{
    Queue q = new Queue();

    public void addToDatabase(String value,boolean isBusy){
        if(isBusy){
            q.enqueue(value);
            System.out.println("Call is in Waiting.");
        }
        else{
            if(q.isEmptyQueue()){
                System.out.println("Call is being Served :"+ value);
            }
            else{
                q.enqueue(value);
                System.out.println("Call of the Person is Served :"+q.displayFront());
                q.dequeue();
            }   
        }
        System.out.print("People in Queue : ");
        q.displayQueue();
    }


    public static void main(String[] args){
        //Driver code.
        Scanner sc = new Scanner(System.in);
        Calls cdb = new Calls();
        while(true){
            Random r = new Random();
            boolean isBusy = r.nextBoolean();

            System.out.print("Enter The caller : ");
            String value = sc.next();

            cdb.addToDatabase(value,isBusy);

            System.out.print("\nPree 1 to Continue or 0 to Exit : ");
            int op = sc.nextInt();
            if(op==0){
                break;
            }
        }     
    }
}
